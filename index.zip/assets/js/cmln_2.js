





// ANIMACIÓN BOTONES MENU CONFORME VAYA BAJANDO 
$(document).ready(function () {
    // Función para actualizar las clases del menú según la posición del contenido
    function actualizarMenu() {
        // Obtener la posición vertical del scroll
        var scrollPosition = $(window).scrollTop();

        // Iterar sobre cada contenido y verificar si está visible en la pantalla
        $('[id^="contenido_"]').each(function () {
            // Verificar si el elemento está definido
            if ($(this).length) {
                var contentOffset = $(this).offset().top-150;
                var contentHeight = $(this).outerHeight();

                if (scrollPosition >= contentOffset && scrollPosition < contentOffset + contentHeight) {
                    // Obtener el número de contenido desde el ID
                    var contentNumber = $(this).attr('id').split('_')[1];

                    // Eliminar la clase 'active' de todos los elementos del menú
                    $('.i_menu').removeClass('active');

                    // Agregar la clase 'active' al elemento del menú correspondiente
                    $('.menu_'.concat(contentNumber)).addClass('active');
                }
            }
        });


        /**Cambiar color btn fixed */
        $('.c-menu').each(function () {
            var contentOffset = $(this).offset().top-400;
            var contentHeight = $(this).outerHeight();

            if(scrollPosition >= contentOffset){
                $('.btn-fixed-call').addClass('active');
                $('.c-subir').addClass('active');
                $('.c-msj').addClass('active');
            }else{
                $('.btn-fixed-call').removeClass('active');
                $('.c-subir').removeClass('active');
                $('.c-msj').removeClass('active');
            }
        });


    }


    function subir(){
        $('html, body').scrollTop($("#header_page").offset().top);
    }

    // Llamar a la función al cargar la página y al desplazarse
    actualizarMenu();

    $(window).scroll(function () {
        actualizarMenu();
    });
});





// FIXED MENU
$(document).ready(function () {
    var menu = $(".c-menu");
    var menuOffset = menu.offset().top;

    $(window).scroll(function () {
        var scrollPosition = $(window).scrollTop();

        if (scrollPosition >= menuOffset) {
            // Si el scroll ha pasado la posición del menú, agregar la clase "fixed"
            menu.addClass("c-fixed");
        } else {
            // Si el scroll está por encima de la posición del menú, quitar la clase "fixed"
            menu.removeClass("c-fixed");
        }
    });
});






// IN TRANSITION

$(document).ready(function () {
    // Función para agregar la clase 'active' cuando el elemento entra en la pantalla
    function fadeInOnScroll() {
        $(document).ready(function () {
            // Función para agregar la clase 'active' y aplicar efectos cuando el elemento entra en la pantalla
            function applyEffectsOnScroll() {
                $(".fade-in").each(function () {
                    var position = $(this).offset().top;
                    var scroll = $(window).scrollTop();
                    var windowHeight = $(window).height();
                    var delay = parseInt($(this).data('delay')) || 0;
                    var duration = parseInt($(this).data('duration')) || 1000; // Duración predeterminada: 1000 ms
        
                    if (scroll > position - windowHeight + 100) {
                        setTimeout(function () {
                            $(this).css({ transition: 'opacity ' + duration + 'ms ease-in-out, transform ' + duration + 'ms ease-in-out' }).addClass("active");
                        }.bind(this), delay);
                    }
                });

                $(".fade-in-top").each(function () {
                    var position = $(this).offset().top;
                    var scroll = $(window).scrollTop();
                    var windowHeight = $(window).height();
                    var delay = parseInt($(this).data('delay')) || 0;
                    var duration = parseInt($(this).data('duration')) || 1000; // Duración predeterminada: 1000 ms
        
                    if (scroll > position - windowHeight + 100) {
                        setTimeout(function () {
                            $(this).css({ transition: 'opacity ' + duration + 'ms ease-in-out, transform ' + duration + 'ms ease-in-out' }).addClass("active");
                        }.bind(this), delay);
                    }
                });


                $(".fade-in-bottom").each(function () {
                    var position = $(this).offset().top;
                    var scroll = $(window).scrollTop();
                    var windowHeight = $(window).height();
                    var delay = parseInt($(this).data('delay')) || 0;
                    var duration = parseInt($(this).data('duration')) || 1000; // Duración predeterminada: 1000 ms
        
                    if (scroll > position - windowHeight + 100) {
                        setTimeout(function () {
                            $(this).css({ transition: 'opacity ' + duration + 'ms ease-in-out, transform ' + duration + 'ms ease-in-out' }).addClass("active");
                        }.bind(this), delay);
                    }
                });

                $(".fade-in-left").each(function () {
                    var position = $(this).offset().top;
                    var scroll = $(window).scrollTop();
                    var windowHeight = $(window).height();
                    var delay = parseInt($(this).data('delay')) || 0;
                    var duration = parseInt($(this).data('duration')) || 1000; // Duración predeterminada: 1000 ms
        
                    if (scroll > position - windowHeight + 100) {
                        setTimeout(function () {
                            $(this).css({ transition: 'opacity ' + duration + 'ms ease-in-out, transform ' + duration + 'ms ease-in-out' }).addClass("active");
                        }.bind(this), delay);
                    }
                });

                $(".fade-in-right").each(function () {
                    var position = $(this).offset().top;
                    var scroll = $(window).scrollTop();
                    var windowHeight = $(window).height();
                    var delay = parseInt($(this).data('delay')) || 0;
                    var duration = parseInt($(this).data('duration')) || 1000; // Duración predeterminada: 1000 ms
        
                    if (scroll > position - windowHeight + 100) {
                        setTimeout(function () {
                            $(this).css({ transition: 'opacity ' + duration + 'ms ease-in-out, transform ' + duration + 'ms ease-in-out' }).addClass("active");
                        }.bind(this), delay);
                    }
                });


                $(".cont-niv-html").each(function () {
                    var position = $(this).offset().top-200;
                    var scroll = $(window).scrollTop();
                    var windowHeight = $(window).height();
                    var delay = parseInt($(this).data('delay')) || 0;
                    var duration = parseInt($(this).data('duration')) || 1000; // Duración predeterminada: 1000 ms
        
                    if (scroll > position - windowHeight + 10) {
                        setTimeout(function () {
                            $(this).css({ transition: 'opacity ' + duration + 'ms ease-in-out, transform ' + duration + 'ms ease-in-out' }).addClass("active");
                        }.bind(this), delay);
                    }
                });


            }
        
            // Llamar a la función al cargar la página y al desplazarse
            applyEffectsOnScroll();
        
            $(window).scroll(function () {
                applyEffectsOnScroll();
            });
        });
        
    }

    // Llamar a la función al cargar la página y al desplazarse
    fadeInOnScroll();

    $(window).scroll(function () {
        fadeInOnScroll();
    });


    $("#btn_youtube").click(function () {
        //alert('df');
        $('#youtube-prev-1').removeClass('active');
        $('#youtube-1').addClass('active');
        stopVideo2();
        PlayVideo();
    });

    $("#btn_youtube_2").click(function () {
        //alert('df');
        $('#youtube-prev-2').removeClass('active');
        $('#youtube-2').addClass('active');

        stopVideo();
        PlayVideo2();
    });

    
});

